"""Privacy integration tests."""
